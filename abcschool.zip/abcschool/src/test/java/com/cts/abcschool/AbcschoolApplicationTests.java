package com.cts.abcschool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcschoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
