package com.cts.abcschool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcschoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcschoolApplication.class, args);
	}

}
